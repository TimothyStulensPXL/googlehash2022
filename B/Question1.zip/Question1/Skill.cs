﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Question1
{
    public class Skill
    {
        public string Name { get; set; }
        public int Level { get; set; }

        public Contributor Contributor { get; set; }
    }
}
